-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2024 at 10:56 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `import_export`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE `cat` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`id`, `name`) VALUES
(9, 'Hoodie'),
(10, 'Foot Wear'),
(12, 'Gloves'),
(13, 'Women'),
(15, 'T-shirts');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int(20) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `size` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `totalorPrice` decimal(10,2) NOT NULL,
  `user_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`id`, `item_id`, `qty`, `size`, `color`, `totalorPrice`, `user_id`) VALUES
(9, '4', '10', 'Small', 'Black', 0.00, '4'),
(13, '6', '10', 'Small', 'Black', 0.00, '8'),
(14, '7', '80', 'Small', 'Black', 0.00, '8'),
(15, '4', '4', 'Small', 'Black', 0.00, '8'),
(18, '6', '10', 'Small', 'Black', 0.00, '4'),
(20, '23', '5', 'Small', 'Black', 0.00, '1'),
(25, '14', '4', 'Small', 'Red', 0.00, '4'),
(26, '12', '8', 'Small', 'black', 0.00, '4'),
(27, '28', '2', '36', 'Black', 0.00, '1'),
(28, '27', '3', '36', 'Black', 0.00, '2'),
(30, '31', '3', '36', 'Black', 7500.00, '10'),
(32, '28', '2', '36', 'Black', 10000.00, '10');

-- --------------------------------------------------------

--
-- Table structure for table `fb`
--

CREATE TABLE `fb` (
  `id` int(20) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fb`
--

INSERT INTO `fb` (`id`, `user_id`, `detail`) VALUES
(5, '4', 'nice product'),
(6, '4', 'HELLOSIR'),
(7, '4', 'Muhammad Fahad'),
(8, '9', 'HELLO SIR WHO ARE YOU');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `city` varchar(200) NOT NULL,
  `cnic` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `status` varchar(200) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `email`, `password`, `city`, `cnic`, `number`, `address`, `status`, `role`) VALUES
(1, 'Admin', 'admin@yahoo.com', 'admin', '', 'CNIC', 'Number', 'This is my Address', 'Confirm', 'admin'),
(2, 'Adil', 'Adil@gmail.com', 'adil', '', '123456789', '03400424132', 'Daska', 'Pending', 'user'),
(3, 'sadaf', 'sadaf@yahoo.com', 'sadaf', '', '12345', '03104455209', 'adddress', 'Confirm', 'user'),
(4, 'Nouman', 'nouman@gmail.com', '123', '', '677898877655', '557576575576576', 'Daska', 'Confirm', 'user'),
(5, 'Ali Tahir', 'tahir@gmail.com', '123', 'Daska', '8899766555454', '03446789876', 'Lahore', 'Confirm', 'user'),
(6, 'Remzan', 'remzan@gmail.com', '123', 'Daska', '3460189099877', '03087898789', 'Daska', 'Confirm', 'user'),
(7, 'Muhammad Fahad', 'fahadshahidxd@gmail.com', 'trsrs45e', 'Sailkot', '3460133543543', '03206354570', 'Awami Road\r\nDaska', 'Confirm', 'user'),
(8, 'fahad ', 'fahad@gmail.com', '123', 'Daska', '3460198123467', '0321987678', 'Muhala Islam Pura\r\n', 'Confirm', 'user'),
(9, 'Muhammad Fahad', 'fahadmughal@gmail.com', '123', 'Sailkot', '434648545', '023972923', 'Awami Road\r\nDaska', 'Confirm', 'user'),
(10, 'Mughal', 'fahad45@gmail.com', '12345', 'Sailkot', '32332', '03206354570', 'Awami Road\r\nDaska', 'Pending', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `my_order`
--

CREATE TABLE `my_order` (
  `id` int(20) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `b_nam` varchar(255) NOT NULL,
  `b_account` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `size` varchar(150) NOT NULL,
  `color` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `my_order`
--

INSERT INTO `my_order` (`id`, `item_id`, `user_id`, `contact`, `address`, `city`, `province`, `b_nam`, `b_account`, `date`, `role`, `qty`, `size`, `color`) VALUES
(3, '4', '5', '03446789876', 'Lahore', 'Daska', 'Punjab', 'HBL', 'Pk001HBL45698712467', '2024-07-07 08:47:00', 'Pending', '5', 'Small', 'Black'),
(4, '4', '4', '557576575576576', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-07 22:46:57', 'Recieved', '5', 'Small', 'Black'),
(5, '1', '1', 'Number899099', 'This is my Addressjohh', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 00:21:05', 'Pending', '5', '', ''),
(6, '6', '1', 'Number899099', 'This is my Addressjohh', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 00:21:05', 'Pending', '80', 'Small', 'Black'),
(7, '17', '1', 'Number899099', 'This is my Addressjohh', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 11:56:03', 'Recieved', '', 'Small', 'Black'),
(8, '11', '1', 'Number899099', 'This is my Addressjohh', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 11:56:03', 'Pending', '15', 'Small', 'Black'),
(9, '4', '4', '557576575576576', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 12:52:22', 'Pending', '10', 'Small', 'Black'),
(10, '6', '1', 'Number980980979', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 18:13:04', 'Pending', '7', 'Small', 'Black'),
(11, '18', '1', 'Number980980979', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 18:13:04', 'Pending', '50', 'Small', 'Black'),
(12, '4', '1', 'Number980980979', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 18:13:04', 'Pending', '10', 'Small', 'Black'),
(13, '15', '1', 'Number980980979', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 18:13:04', 'Pending', '10', 'Small', 'Black'),
(14, '10', '1', 'Number980980979', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-08 18:13:04', 'Pending', '50', 'Small', 'Black'),
(15, '22', '1', 'Number980980979', 'This is my Addressjohh', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-11 18:07:27', 'Pending', '10', 'Small', 'Black'),
(16, '14', '9', '023972923', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-11 18:46:23', 'Recieved', '5', 'Small', 'red'),
(17, '24', '10', '03206354570', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-11 19:26:57', 'Recieved', '10', 'medium', 'Black'),
(18, '9', '10', '03206354570', 'Awami Road', 'Sailkot', 'Punjab', 'HBL', 'Pk0023HBL789654349', '2024-07-12 20:43:00', 'Pending', '10', 'Small', 'red');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `payment_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payment_id`, `payer_id`, `payer_name`, `payer_email`, `item_id`, `item_name`, `currency`, `amount`, `status`, `created_at`) VALUES
(1, '351791916P2084814', 'NZCZ24PF8LVTA', 'John Doe', 'sb-ivg3331911943@business.example.com', '', 'White Half T-Shirt', 'USD', '7500.00', 'Completed', '2024-07-27 01:42:21'),
(2, '9SK45847071254431', 'NZCZ24PF8LVTA', 'John Doe', 'sb-ivg3331911943@business.example.com', '', 'White Half T-Shirt', 'USD', '7500.00', 'Completed', '2024-07-27 01:44:42'),
(3, '4DF63305YN784923U', 'NZCZ24PF8LVTA', 'John Doe', 'sb-ivg3331911943@business.example.com', '', 'White Half T-Shirt', 'USD', '7500.00', 'Completed', '2024-07-27 01:46:45'),
(4, '1B848722XP162994L', 'NZCZ24PF8LVTA', 'John Doe', 'sb-ivg3331911943@business.example.com', '', 'Men Gray Hoodie', 'USD', '10000.00', 'Completed', '2024-07-27 01:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `cat_id` varchar(255) NOT NULL,
  `role` varchar(11) NOT NULL,
  `pro_feature` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `details`, `price`, `qty`, `cat_id`, `role`, `pro_feature`) VALUES
(27, 'Men Hoodie', 'istockphoto-150519390-2048x2048.jpg', 'Nice Product with Flexibility', '3500', '47', '9', 'Enable', 'New'),
(28, 'Men Gray Hoodie', 'istockphoto-658650278-2048x2048.jpg', 'Good', '5000', '33', '9', 'Enable', 'New'),
(29, 'Men Gray Appar', 'istockphoto-892376062-2048x2048.jpg', 'Nice', '2500', '50', '9', 'Enable', 'Old'),
(30, 'Half T-Shirt', 'istockphoto-1125110782-2048x2048.jpg', 'Nice', '2500', '50', '15', 'Enable', 'Old'),
(31, 'White Half T-Shirt', 'istockphoto-1490616593-2048x2048.jpg', 'Nice', '2500', '12', '15', 'Enable', 'New'),
(32, 'Slim Fit Shirt', 'istockphoto-523415383-2048x2048.jpg', 'Nice', '2500', '50', '15', 'Enable', 'Old');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat`
--
ALTER TABLE `cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fb`
--
ALTER TABLE `fb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_order`
--
ALTER TABLE `my_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cat`
--
ALTER TABLE `cat`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `fb`
--
ALTER TABLE `fb`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `my_order`
--
ALTER TABLE `my_order`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
