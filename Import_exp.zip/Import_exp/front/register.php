<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>
<!-- banner -->
<div class="main-w3pvt">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-6 style-banner">
						<div class="style-banner-inner">
							<h3 class="font-weight-bold text-uppercase"><span class="font-weight-normal">ZIMI</span> CK <span class="font-weight-normal"> INTERNATIONAL </span></h3>
							<p class="mt-3">Welcome To My Website</p>
							<a href="#" class="btn button-style mt-sm-5 mt-4">Read More</a>
						</div>
					</div>
					<div class="col-lg-6 img-banner-w3 text-center">
						<div class="csslider infinity" id="slider1">
							<input type="radio" name="slides" checked="checked" id="slides_1" />
							<input type="radio" name="slides" id="slides_2" />
							<input type="radio" name="slides" id="slides_3" />
							<input type="radio" name="slides" id="slides_4" />
							<input type="radio" name="slides" id="slides_5" />
							<ul class="banner_slide_bg">
								<li>
									<img src="images/cart-2.png" alt="" class="img-fluid w-50">
								</li>
								<li>
									<img src="images/details-2.png" alt="" class="img-fluid w-50">
								</li>
								<li>
									<img src="images/new-4.png" alt="" class="img-fluid w-50">
								</li>
								<li>
									<img src="images/product-4.png" alt="" class="img-fluid w-50">
								</li>
								<li>
									<img src="images/product.png" alt="" class="img-fluid w-50">
								</li>
							</ul>
							<div class="navigation">
								<div>
									<label for="slides_1"></label>
									<label for="slides_2"></label>
									<label for="slides_3"></label>
									<label for="slides_4"></label>
									<label for="slides_5"></label>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- //banner -->

<!-- page details -->
<div class="breadcrumb-w3ls py-1">
	<div class="container">
		<ol class="breadcrumb m-0">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Login</li>
		</ol>
	</div>
</div>
<!-- //page details -->




	<!-- contact  -->
	<section class="contact py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-5 font-weight-bold">Register Page <span>Please Enter Valid Information</span></h3>
			<div class="row">
				<!-- contact form -->
				<div class="col-lg-12 contact-us1-bottom w3layouts-w3ls">
					<form action="" method="post">
						

						<div class="form-group">
							<input type="text" class="form-control" placeholder="Name" name="name" required="">
						</div>


						<div class="form-group">
							<input type="email" class="form-control" placeholder="Email" name="email" required="">
						</div>



						<div class="form-group">
							<input type="password" class="form-control" placeholder="Password" name="password" required>
						</div>


						<div class="form-group">
							<input type="text" class="form-control" placeholder="City" name="city" required>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" placeholder="CNIC" name="cnic" required="">
						</div>


						<div class="form-group">
							<input type="text" class="form-control" placeholder="Contact Number" name="number" required="">
						</div>


						<div class="form-group">
							<textarea class="form-control" placeholder="Address" name="address" required></textarea>
						</div>



						<div class="form-group">
						<button type="submit" name="register" class="btn">Register</button>
						</div>

						<div class="form-group">
						<a href="login.php" class="pull-right">Have a account ?</a>
						</div>



						<?php 


						if (isset($_POST['register'])) {
							
							$name 		= $_POST['name'];
							$cnic 		= $_POST['cnic'];
							$email 		= $_POST['email'];
							$password 	= $_POST['password'];
							$city 	    = $_POST['city'];
							$number 	= $_POST['number'];
							$address 	= $_POST['address'];

							// for check user email is already exist or not using select query if email is already exist then this email or user is not regisgter successfully

							$check 		= "SELECT * FROM members WHERE email = '$email'";
							$check_run 	= $database->query($check);
							$num 		= $check_run->num_rows;

							if ($num == 0) {

								// if the user email is not exist in the database then using insert query to enter data into the database
								
								$reg 	= "INSERT INTO members(name, email, cnic, city, number, password, address, role, status) VALUES('{$name}','{$email}','{$cnic}', '{$city}','{$number}','{$password}','{$address}','user', 'Pending')";

								$reg_run = $database->query($reg);

								if ($reg_run) {
									
									echo "<p class='alert alert-info'>User Has Been Successfully Added</p>";

								}
								else{

									echo "<p class='alert alert-danger'>User Has Not Been Successfully Added</p>";

								}

							}else{

								echo "<p class='alert alert-danger'>Email Already Taken</p>";

							}

						}



						?>




					</form>
				</div>
				

</div>
</div>
</section>







<?php include("include/footer.php"); ?>