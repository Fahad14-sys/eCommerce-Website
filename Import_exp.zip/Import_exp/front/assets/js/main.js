/*=============== SHOW MENU ===============*/


/*===== MENU SHOW =====*/
/* Validate if constant exists */


/*===== MENU HIDDEN =====*/
/* Validate if constant exists */


/*=============== SHOW CART ===============*/
const cart=document.getElementById('cart'),
cartshop=document.getElementById('cart__shop'),
cartclose=document.getElementById('cart__close')

              /*CART SHOW*/
/* Validate if constant exists */
if(cartshop) {
	cartshop.addEventListener("click", () => {
		cart.classList.add('show-cart')
	})
}

/*===== CART HIDDEN =====*/
/* Validate if constant exists */

if(cartclose) {
	cartclose.addEventListener("click", () => {
		cart.classList.remove('show-cart')
	})
}

/*=============== SHOW LOGIN ===============*/
const login=document.getElementById('login'),
loginButton= document.getElementById('login-button'),
loginClose= document.getElementById('login-close')

/*===== LOGIN SHOW =====*/
/* Validate if constant exists */
if(loginButton) {
	loginButton.addEventListener("click", () => {
		login.classList.add('show-login')
	})
}


/*===== LOGIN HIDDEN =====*/
/* Validate if constant exists */
if(loginClose) {
	loginClose.addEventListener("click", () => {
		login.classList.remove('show-login')
	})
}

/*=============== HOME SWIPER ===============*/
 var homeswiper=new Swiper(".home-swiper", {
 	spacebetween:30,
 	loop:'true',

      pagination: {
        el: ".swiper-pagination",
        clickable:true,
      },
    });



/*=============== CHANGE BACKGROUND HEADER ===============*/
function ScrollHeader() {
       const header = document.getElementById('header')
       if (this.scrolly >=50)header.classList.add('scroll-header');else header.classList.remove('scroll-header')
	// body...
}
window.addEventListener('scroll', ScrollHeader)


/*=============== NEW SWIPER ===============*/

var newswiper=new Swiper(".new-swiper", {
 	spacebetween:16,
 	CenteredSlides:true,
 	slidesPerView:"auto",
 	loop:'true',
    });

/*=============== SHOW SCROLL UP ===============*/ 
function scrollUp() {
	const scrollUp = document.getElementById('scroll-up');
	//when the class

	if(this.scrollY >= 350) scrollUp.classList.add('show-scroll');
	else scrollUp.classList.remove('show-scroll')
}
window.addEventListener('scroll', scrollUp);

/*=============== LIGHT BOX ===============*/


/*=============== QUESTIONS ACCORDION ===============*/
const accordionItem = document.querySelectorAll('.questions__item')
accordionItem.forEach((item)=>{
	const accordionHeader=item.querySelector('.questions__header')

	accordionHeader.addEventListener('click',() => {
		const openItem=document.querySelector('.accordion-open')
		toogleItem(item)
	})
})
const toogleItem = (item) => {
	const accordionContent = item.querySelector('.questions__content')
	if(item.classList.contains('accordion-open')){
		accordionContent.removeAttribute('style')
	}
	accordionContent.style.height= accordionContent.scrollHeight+'px'
	item.classList.add('accordion-open') 
}

/*=============== STYLE SWITCHER ===============*/
const styleSwitcherToggle=document.querySelector(".style__switcher-toogler");
styleSwitcherToggle.addEventListener("click",()=> {
	document.querySelector(".style__switcher").classList.toggle("open");
})

//hide style switcher during scroll//
window.addEventListener("scroll",()=>{
	if (document.querySelector(".style__switcher").classList.contains("open")) {
	document.querySelector(".style__switcher").classList.remove("open");
		
	}
})

//THEME COLOR//
 function themecolors()
 {
 	const colorstyle=document.querySelector(".js-color-style"),
 	themecolorscontainer = document.querySelector(".js-theme-colors");
 	themecolorscontainer.addEventListener("click",({target})=>{
 		if (target.classList.contains("js-theme-color-item")) {
 		localstoragey.setitem("color",target.getAtribute)("data-js-theme-colors")
 	    setcolors();
 	}
 	})
 	function setcolors()
 	{
 		let path=colorstyle.getAttribute("href").split("/");
 		path=path.slice(0,path.length -1);
 		colorstyle.setAttribute("href",path.join("/")+"/"+localstorage.getlines("color")+".css");
 		console.log(path);
 	}
 }

 themecolors()