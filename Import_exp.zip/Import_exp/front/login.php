<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>
<style>
	.new_img1{
       
    width: 60%;
    height: 30vw;
    object-fit: cover;

    }
</style>
<!-- banner -->
<div class="main-w3pvt">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-6 style-banner">
						<div class="style-banner-inner">
							<h3 class="font-weight-bold text-uppercase"><span class="font-weight-normal">ZIMI</span> CK <span class="font-weight-normal"> INTERNATIONAL </span></h3>
							<p class="mt-3">Welcome To My Website</p>
							<a href="#" class="btn button-style mt-sm-5 mt-4">Read More</a>
						</div>
					</div>
					 <?php 
                   if (isset($cat)) {?>
                       <div class="col-lg-6 img-banner-w3 text-center">
                        <div class="csslider infinity" id="slider1">
                            <input type="radio" name="slides" checked="checked" id="slides_1" />
                            <input type="radio" name="slides" id="slides_2" />
                            <input type="radio" name="slides" id="slides_3" />
                            <input type="radio" name="slides" id="slides_4" />
                            <input type="radio" name="slides" id="slides_5" />
                            <ul class="banner_slide_bg">
                            <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND cat_id = '$cat' ";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }
                   ?> 

                            
                            
                                <li>
                                    <img src="../back/images/<?php echo $image; ?>" alt="" class="img-fluid new_img1">
                                </li>
                                 <?php } }?>
                               
                            </ul>
                   
                            <div class="navigation">
                                <div>
                                    <label for="slides_1"></label>
                                    <label for="slides_2"></label>
                                    <label for="slides_3"></label>
                                    <label for="slides_4"></label>
                                    <label for="slides_5"></label>
                                </div>
                            </div>

                        </div>
                       
                    </div>
  </div>
            </div>
        </div>
                <?php } else {?>

              
                  
                       <div class="col-lg-6 img-banner-w3 text-center">
                        <div class="csslider infinity" id="slider1">
                            <input type="radio" name="slides" checked="checked" id="slides_1" />
                            <input type="radio" name="slides" id="slides_2" />
                            <input type="radio" name="slides" id="slides_3" />
                            <input type="radio" name="slides" id="slides_4" />
                            <input type="radio" name="slides" id="slides_5" />
                            <ul class="banner_slide_bg">
                            <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }
                   ?> 

                            
                            
                                <li>
                                    <img src="../back/images/<?php echo $image; ?>" alt="" class="img-fluid new_img1">
                                </li>
                                 <?php } }?>
                               
                            </ul>
                   
                            <div class="navigation">
                                <div>
                                    <label for="slides_1"></label>
                                    <label for="slides_2"></label>
                                    <label for="slides_3"></label>
                                    <label for="slides_4"></label>
                                    <label for="slides_5"></label>
                                </div>
                            </div>

                        </div>
                       
                    </div>

               

                </div>
            </div>
        </div>
                  <?php  }?>
		<!-- //banner -->


<!-- page details -->
<div class="breadcrumb-w3ls py-1">
	<div class="container">
		<ol class="breadcrumb m-0">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item active">Login</li>
		</ol>
	</div>
</div>
<!-- //page details -->




	<!-- contact  -->
	<section class="contact py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-5 font-weight-bold">Login Page <span>Please Enter Valid Account</span></h3>
			<div class="row">
				<!-- contact form -->
				<div class="col-lg-12 contact-us1-bottom w3layouts-w3ls">
					<form action="" method="post">
						

						<div class="form-group">
							<input type="email" class="form-control" placeholder="Email" name="email" required="">
						</div>


						<div class="form-group">
							<input type="password" class="form-control" placeholder="Password" name="password" required="">
						</div>

						<div class="form-group">
						<button type="submit" name="login" class="btn">Login</button>
						</div>

						<div class="form-group">
						<a href="register.php" class="pull-right">Don't have a account ?</a>
						</div>


						<?php 


						if (isset($_POST['login'])) {
							
							$email 		= $_POST['email'];
							$password 	= $_POST['password'];
							// check same email and password and login
							$check 		= "SELECT * FROM members WHERE email = '$email' AND password = '$password'";
							// run query in to database
							$check_run 	= $database->query($check);
							$num 		= $check_run->num_rows;
							// fetch data from datebase and enter into fetch variable
							$fetch 		= $check_run->fetch_assoc();


							if ($num == 0) {
									

								echo "<p class='alert alert-danger'>Email / Password Wrong</p>";
							

							}elseif($num == 1 AND $fetch['role'] == 'admin'){

								$_SESSION['id'] = $fetch['id'];
								$_SESSION['role'] = "admin";
								// header function is use to redirect from one page to another page
								header("Location: index.php");

							}elseif($num == 1 AND $fetch['role'] == 'user'){
            
				            $_SESSION['id']         = $fetch['id'];
				            $_SESSION['role']  = "user";
				            header("Location: index.php");
        				}

						}



						?>




					</form>
				</div>
				

</div>
</div>
</section>







<?php include("include/footer.php"); ?>