<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>

<?php 
// first we get id of the product when user click on the add to card icon

if (isset($_GET['id'])) {
	$id = $_GET['id'];
	
	$select 	= "SELECT * FROM product WHERE id = '$id'";
	$run 		= $database->query($select);
	$fetch 		= $run->fetch_assoc();
	$cat_id 	= $fetch['cat_id'];
	$name 		= $fetch['name'];
	$price 		= $fetch['price'];
	$image 		= $fetch['image'];
	$qty 		= $fetch['qty'];
	$details 	= $fetch['details'];
	$cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
	$qry_run = $database->query($cat_qry);
	$qry_num = $qry_run->num_rows; 
	if($qry_num == 0){

		$cat_name = '-';

	}else{

		$cat_row = $qry_run->fetch_assoc();
		$cat_name = $cat_row['name'];

	}


}


if (isset($_SESSION['id'])) {
	
	$user_id = $_SESSION['id'];
	
}





?>


<div class="main-banner-2" id="home">
</div>


<!-- page details -->
<div class="breadcrumb-w3ls py-1">
    <div class="container">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $cat_name; ?></li>
        </ol>
    </div>
</div>
<!-- //page details -->




<!-- about  -->
<section class="about-inner py-5">
    <div class="container pt-xl-5 pt-lg-3">
        <div class="row">
            <div class="col-lg-6 w3lsits_works-grid1 mt-lg-0 mt-sm-5 mt-4">
                <img src="../back/images/<?php echo $image; ?>" alt="" class="img-fluid" />
            </div>
            <div class="col-lg-6 w3lsits_works-grid mt-xl-4" style="margin-top: -74px !important;">
                <h3 class="title-w3"><?php echo $name; ?></h3>
                <hr>
                <div class="wthree-bottom">
                    <h6 class="subheading-w3ls text-uppercase text-dark mb-4">Price <span
                            class="font-weight-bold"><?php echo $price; ?></span></h6>
                    <span>Qty | <?php echo $qty; ?></span><br><br>
                    <span>Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>

                    <br><br>
                    <span>
                        <details>
                            <summary>Products Details</summary>
                            <p><?php echo $details; ?></p>
                        </details>
                    </span><br>

                    <?php 
                             
                       // session is used for the check user login or not 
						if (isset($_SESSION['id'])) {
							?>

                    <form method="POST">
                        <input type="number" name="qty" placeholder="Enter Quantity" required><br><br>
                        <input type="text" name="size" placeholder="Enter Size" required><br>
                        <input type="text" name="color" placeholder="Enter Colour" required>
                        <input type="hidden" name="item_id" value="<?php echo $id; ?>">
                        <input type="submit" name="add" class="btn button-style mt-sm-5 mt-4" value="Add to Cart" style="margin-left: -193px;
							position: relative;
							top: 39px;">

                    </form>

                    <?php }else{ echo "<p>Please Login First</p>"; } ?>





                    <?php 


						if (isset($_POST['add'])) {

							$p_qty 		= $_POST['qty'];
							$item_id 	= $_POST['item_id'];
							$size       = $_POST['size'];
							$color       = $_POST['color'];
							$totalprice= $price*$p_qty;

							if ($p_qty>$qty) {
								echo '<script>alert("Your quantity is more than our product quantity")</script>';
							}

							else{
								$check 		= "SELECT * FROM checkout WHERE user_id = '$user_id' AND item_id = '$item_id'";
							$check_run 	= $database->query($check);
							$num_rows 	= $check_run->num_rows;

							if ($num_rows == 0) {
								
								$insert = "INSERT INTO checkout(user_id, item_id, qty,size,color,totalorPrice) 
								VALUES('$user_id','$item_id','$p_qty','$size', '$color','$totalprice')";
								$insert_run = $database->query($insert);
								if ($insert_run) {

									echo "<p class='alert alert-info' style='margin-left: 1px;width: 450px;margin-top: 60px;'>Products Has been added into the Cart</p>";

								}else{

									echo "<p class='alert alert-danger' style='margin-left: 1px;width: 450px;margin-top: 60px;'>Products adding Error</p>";

								}

							}else{

								echo "<p class='alert alert-danger' style='margin-left: 1px;width: 450px;margin-top: 60px;'>Already Added</p>";

							}

						}
						$newQuantity = $qty - $p_qty;
						
						$updateQuery = "UPDATE `product` SET `qty`='$newQuantity' WHERE id = '$id'";
						$update_run = $database->query($updateQuery);
						if ($update_run) {
							echo "Quantity Update Successfully";
						}else{
							echo "Something Wrong";
						}

							}





						?>





                </div>
            </div>
        </div>
    </div>
</section>
<!-- //about -->













<?php include("include/footer.php"); ?>