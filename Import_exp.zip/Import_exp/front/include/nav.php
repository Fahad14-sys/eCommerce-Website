
		<!-- header -->
		<header>
			<div class="container-fluid">
				<div class="header d-md-flex bg-light justify-content-between align-items-center py-sm-4 py-3 px-xl-5 px-lg-3 px-2">
					<!-- logo -->
					<div id="logo">
						<h1><a class="" href="index.php"> ZIMICK INTERNATIONAL </a></h1>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle toogle-2">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu">
								
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="index.php">Home</a></li>
								

								<?php 

								$select = "SELECT * FROM cat";
								$run 	= $database->query($select);
								if ($run->num_rows) {
									while ($a = $run->fetch_assoc()) {

										$c_id = $a['id'];
										$c_name = $a['name'];

										?>
								
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="index.php?cat=<?php echo $c_id ?>"><?php echo $c_name; ?></a></li>

									<?php } } ?>
								



								<?php if (isset($_SESSION['id'])) { ?>

								<?php if(isset($_SESSION['role']) AND $_SESSION['role'] != 'user'){ ?> 

								<li><a href="../back/index.php" style="color: #cf574e">Account</a></li>
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="checkout.php" style="color: #4e91cf">Shoping Cart</a></li>
								

								<?php }else{ ?>

								<li><a href="../back/user.php" style="color: #cf574e">Account</a></li>
								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="checkout.php" style="color: #4e91cf">Shoping Cart</a></li>

								 <?php } ?>
								<?php }else{ ?> 


								<li><a href="login.php" style="color: #cf574e">Login</a></li>

								<li class="mx-lg-4 mx-md-3 my-md-0 my-2"><a href="register.php" style="color: #4e91cf">Register</a></li>

								<?php } ?>
								
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
		<!-- //header -->