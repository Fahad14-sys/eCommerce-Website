	<!-- footer -->
	<footer class="footer section mt-5">
            <div class="footer__container container grid">
                <!--FOOTER CONTENT 1!-->
                <div class="footer__content">
                    <a href="#" class="footer__logo">
                        <i class="bx bx-shopping-bag footer-logo-icon"></i>Zimick-international
                    </a>
                    <p class="footer_description">Enjoy the biggest sale<br>of your life.</p>

                    <div class="footer__social">
                    <a href="#" class="footer__social-link"><i class="bx bxl-facebook"></i></a>

                    <a href="#" class="footer__social-link">
                    <i class="bx bxl-instagram-alt"></i></a>

                    <a href="#" class="footer__social-link">
                    <i class="bx bxl-twitter"></i></a>
                    </div>
                </div>
                <!--FOOTER CONTENT 2!-->
                <div class="footer-content">
                    <h3 class="footer-tittle">About</h3>
                    <ul class="footer_link">
             <li><a href="#" class="footer__link">About Us</a></li>
             <li><a href="#" class="footer__link">Coustomer Support</a></li>
             <li><a href="#" class="footer__link">Support Center</a></li>
                    </ul>
                </div>
                 <!--FOOTER CONTENT 3 !-->
                 <div>
                <div class="footer-content">
                    <h3 class="footer-tittle">Our Services</h3>
                    <ul class="footer_link">
             <li><a href="#" class="footer__link">Shops</a></li>
             <li><a href="#" class="footer__link">Discounts</a></li>
             <li><a href="#" class="footer__link">Shipping mode</a></li>
                    </ul>
                </div>
                 
                 <!--FOOTER CONTENT 4 !-->
                <div class="footer-content">
                    <h3 class="footer-tittle">Our Company</h3>
                    <ul class="footer_link">
             <li><a href="register.php" class="footer__link">Register</a></li>
             <li><a href="#" class="footer__link">Contact Us</a></li>
             <li><a href="#" class="footer__link">About Us</a></li>
                    </ul>
                </div>

            </div>
        <span class="footer-copy">&#169;Crypticalcoder. All rights reserved</span>
    </footer>

    <!------------------ SCROLL UP ----------------->
    <a href="#" class="scrollup" id="scroll-up">
        <i class="bx bx-up-arrow-alt scrollup__icon"></i>
    </a>

    <!---------------- STYLE SWITCHER --------------->
      <div class="style__switcher">
          <div class="style__switcher-toogler s__icon">
              <i class="bx bxs-cog bx-spin"></i>
          </div>
          <h4>Theme Colors</h4>
          <div class="theme__colors js-theme-colors">
              <button type="button" data-js-theme-color="color-1" class="js-theme-color-item  theme__button color-1"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-2" class="js-theme-color-item theme__button color-2"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-3" class="js-theme-color-item theme__button color-3"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-4" class="js-theme-color-item theme__button color-4"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-5" class="js-theme-color-item theme__button color-5"><i class="bx bx-check"></i></button>
          </div>
      </div>
    <!---------------- SWIPER JS -------------------->
    <script src="assets/js/swiper-bundle.min.js"></script>

    <!----------------- JS -------------------->
    <script src="assets/js/main.js"></script>
</body>
</html>
	<!-- //footer -->
	<script src="assets/js/swiper-bundle.min.js"></script>

<!----------------- JS -------------------->
	<script src="assets/js/main.js"></script>
</body>

</html>