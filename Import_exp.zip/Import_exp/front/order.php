<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>


<?php 
echo '<script language="javascript">';
echo 'alert("Your Product is checkout Suceesfully")';
echo '</script>';
$u_id = $_SESSION['id'];
session_start();

if(!empty($_GET))
{
	$_SESSION['product'] = $_GET['item_name'];  
    $_SESSION['txn_id'] = $_GET['tx']; 
    $_SESSION['amount'] = $_GET['amt']; 
    $_SESSION['currency'] = $_GET['cc']; 
    $_SESSION['status'] = $_GET['st']; 
	$_SESSION['payer_id'] = $_GET['payer_id']; 
	$_SESSION['payer_email'] = $_GET['payer_email']; 
	$_SESSION['payer_name'] = $_GET['first_name'].' '.$_GET['last_name'];
	
	date_default_timezone_set('Asia/Kolkata');
	
	$sql="insert into payments (payment_id,payer_id,payer_name,payer_email,item_id,item_name,currency,amount,status,created_at) values ('".$_SESSION['txn_id']."','".$_SESSION['payer_id']."','".$_SESSION['payer_name']."','".$_SESSION['payer_email']."','','".$_SESSION['product']."','".$_SESSION['currency']."','".$_SESSION['amount']."','". $_SESSION['status']."','".date('y-m-d h:i:s')."')";
	
	$result=mysqli_query($database,$sql);
	
	
  if($result)
  {
  header('location:order.php');
  }
  else 
  {
	  echo "Error: " . $sql . "<br>" . mysqli_error($database);
  }
  
}


$select = mysqli_query($database, "SELECT * FROM members WHERE id = '$u_id'");
$a 		= mysqli_fetch_assoc($select);

 ?>
<div class="main-banner-2" id="home">
</div>
<!-- page details -->
<div class="breadcrumb-w3ls py-1">
    <div class="container">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Create you Order</li>
        </ol>
    </div>
</div>
<!-- //page details -->
<section class="py-5 team-w3ls" id="best">
    <div class="container py-xl-5 py-lg-3">
        <div class="col-lg-12 contact-us1-bottom w3layouts-w3ls">
            <div class="form-group">
                <input type="text" name="" class="form-control" value="<?php echo $a['name']; ?>" disabled>
            </div>
            <div class="form-group">
                <input type="text" name="" class="form-control" value="<?php echo $a['cnic']; ?>" disabled>
            </div>
            <div class="alert alert-success">
                <strong>Success!</strong> Payment has been successful
            </div>
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td>Transaction Id</td>
                        <td><?php echo $_SESSION['txn_id'];?></td>
                    </tr>
                    <tr>
                        <td>Product Name</td>
                        <td><?php echo $_SESSION['product'];?></td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td><?php echo $_SESSION['amount'];?></td>
                    </tr>

                    <tr>
                        <td>Payment Status</td>
                        <td><?php echo $_SESSION['status'];?></td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</section>





<?php 


if (isset($_POST['order'])) {
	
	$user_id   		= $_POST['user_id'];
	$contact   		= $_POST['contact'];
	$address   		= $_POST['address'];
	$city   		= $_POST['city'];
	$province   	= $_POST['province'];
	$bank   		= $_POST['bank'];
	$bank_account   = $_POST['bank_account'];

	

	$select_cart 	= mysqli_query($database, "SELECT * FROM checkout WHERE user_id = '$user_id'");
	

	while ($c 		= mysqli_fetch_assoc($select_cart)) {

		$product_id = $c['item_id'];
		$qty_id 	= $c['qty'];
		$size 	    = $c['size'];
		$color    	= $c['color'];

		


		$insert 	= mysqli_query($database, "INSERT INTO my_order(item_id, user_id, contact, address, city, province, b_nam, b_account, date, role, qty,size,color) VALUES('$product_id','$user_id','$contact','$address','$city','$province','$bank','$bank_account',now(),'Pending', '$qty_id','$size','$color')");

		$qty_update = mysqli_query($database, "UPDATE product SET qty = (qty-'$qty_id') WHERE id = '$product_id' ");




	}



	if ($insert) {
		
		header("Location: checkout.php");
		$_SESSION['cart'] = "Your Order Has Been Successfully Added";

		$delete = mysqli_query($database, "DELETE FROM checkout WHERE user_id = '$user_id'");
			
	}

	else

	{


		echo "<p class='alert alert-danger'>SOme THing WEnt WRong</p>";

	}


}


 ?>





<?php include("include/footer.php"); ?>