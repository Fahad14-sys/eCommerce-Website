<?php include "include/header.php";?>
<?php include "include/nav.php";?>
<?php
//Email : sb-ivg3331911943@business.example.com
//Password: 8uGKh?F+
?>


<div class="main-banner-2" id="home">
</div>


<!-- page details -->
<div class="breadcrumb-w3ls py-1">
    <div class="container">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Cart</li>
        </ol>
    </div>
</div>
<!-- //page details -->




<section class="py-5 team-w3ls" id="best">
    <div class="container-fluid py-xl-5 py-lg-3">

        <table class="table table-striped">

            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Colour</th>
                    <th>Total</th>
                    <th>Action</th>
                    <th>Chekcout</th>
                </tr>
            </thead>


            <tbody>
                <tr>
                    <?php

$u_id = $_SESSION['id'];

$get = mysqli_query($database, "SELECT * FROM checkout WHERE user_id = '$u_id'");

if (mysqli_num_rows($get)) {

	$check = 0;

	while ($all = mysqli_fetch_assoc($get)) {
		$id=$all['id'];
		$user_id = $all['user_id'];
		$product_id = $all['item_id'];
		$size = $all['size'];
		$color = $all['color'];
		$totalorPrice=$all['totalorPrice'];

		$select = mysqli_query($database, "SELECT * FROM product WHERE id = '$product_id'");

		if (mysqli_num_rows($select)) {

			while ($a = mysqli_fetch_assoc($select)) {

				?>

                    <td><img src="../back/images/<?php echo $a['image']; ?>" width="100px" height="100px"></td>

                    <td><?php echo $a['name']; ?></td>

                    <td>
                        <?php
					if (isset($_POST['edit'])) {
					?>
                        <form method="POST">
                            <select class="form-control" name="qty">
                                <option disabled selected><?php echo $all['qty']; ?></option>
                                <option disabled>---------</option>
                                <?php

					$count = 1;
					while ($count <= $a['qty']) {

						?>

                                <option><?php echo $count; ?></option>

                                <?php $count++;}?>
                            </select>
                            <br>
                            <input type="hidden" name="new_id" value="<?php echo $all['id']; ?>">
                            <input type="submit" name="update" value="Update" class="btn btn-danger">
                            <input type="submit" name="cancel" value="Cancel" class="btn btn-warning">
                        </form>
                        <?php } else {
					echo $all['qty'];
					?>
                        <br>
                        <br>
                        <form method="POST">
                            <input type="submit" name="edit" class="btn btn-success" value="Edit">
                        </form>
                        <?php }?>
                    </td>


                    <td><span>$</span><?php echo  $a['price']; ?></td>
                    <td><?php echo $all['size']; ?></td>
                    <td><?php echo $all['color']; ?></td>

                    <td><span>$</span><?php echo $totalorPrice?></td>

                    <td align="center">
                        <form method="POST" action="">
                            <input type="hidden" name="del_id" value="<?php echo $all['id']; ?>">
                            <input type="submit" name="remove" class="btn btn-danger" value="Remove">
                        </form>
                    </td>
                    <td align="center">
                            <form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr">
                                <input type="hidden" name="business" value="sb-fsacy31795215@business.example.com">
                                <input type="hidden" name="item_name" value="<?php echo $a['name'];?>">
                                <input type="hidden" name="item_number" value="<?php echo $id?>">
                                <input type="hidden" name="amount" value="<?php echo $totalorPrice;?>">
                                <input type="hidden" name="currency_code" value="USD">
                                <input type="hidden" name="no_shipping" value="1">
                                <input type="hidden" name="cmd" value="_xclick">
                                <input type="hidden" name="return"
                                    value="http://localhost/Import_exp/front/order.php">
                                <input type="hidden" name="cancel_return"
                                    value="http://localhost/Import_exp/front/cancel.php">
                                <div class="card" style="width:400px">
                                    <img class="card-img-top" src="../back/images/<?php echo $a['image']; ?>"
                                        alt="Card image" style="width:100%">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo $a['name'];?></h4>
                                        <p class="card-text">$<?php echo $totalorPrice ?></p>
                                        <button type="submit" class="btn btn-primary">Buy Now</button>
                                    </div>
                                </div>
                        </form>

                    </td>
                </tr>
                <?php
				$check = $check + $totalorPrice;
			}}}

}?>



            </tbody>
            <!-- <tfoot>
                <td colspan="4" align="center"><br><b>Total</b></td>
                <td align="center"><br><b><?php if (isset($check)) {echo $check;} else {echo "No Item Seleted.";}?></b>
                </td>
                <td align="center"><br>
                    <form method="POST" action="order.php">
                        <input type="hidden" name="totla_price" value="<?php echo $check; ?>">
                        <input type="submit" name="chekout" value="Checkout" class="btn btn-warning">
                    </form>

                    <br><br>
                </td>
            </tfoot> -->

        </table>






        <?php

if (isset($_POST['remove'])) {

	$del_id = $_POST['del_id'];

	$delete = mysqli_query($database, "DELETE FROM checkout WHERE id = '$del_id'");

	if ($delete) {

		header("Location: checkout.php");

	} else {

		header("Location: checkout.php");

	}

}

// Update Qty Code Start Here

if (isset($_POST['update'])) {

	$qty_a = $_POST['qty'];
	$new_id = $_POST['new_id'];

	$insert = mysqli_query($database, "UPDATE checkout SET qty = '$qty_a' WHERE id = '$new_id'");
	if ($insert) {
		header("Location: checkout.php");

	} else {
		header("Location: checkout.php");

	}
}

?>








    </div>
</section>








<?php include "include/footer.php";?>