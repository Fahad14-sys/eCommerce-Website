<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>
<style>
    .new_img{
       
    width: 60%;
    height: 15vw;
    object-fit: cover;

    }
    .new_img1{
       
    width: 60%;
    height: 30vw;
    object-fit: cover;

    }
</style>
<?php 




if (isset($_GET['cat'])) {
    
    $cat = $_GET['cat'];

}




?>
<body>
    <!----------------- HEADER -------------------->

<div class="main-w3pvt">
            <div class="container-fluid"><!-- NO margin start page!-->
                <div class="row">
                    <div class="col-lg-6 style-banner">
                        <div class="style-banner-inner">
                            <h3 class="font-weight-bold text-uppercase"><span class="font-weight-normal">ZIMI</span> CK <span class="font-weight-normal"> INTERNATIONAL </span></h3>
                            <p class="mt-3">Welcome To My Website</p>
                            <a href="#" class="btn button-style mt-sm-5 mt-4">Read More</a>
                        </div>
                    </div>
                   <?php 
                   if (isset($cat)) {?>
                       <div class="col-lg-6 img-banner-w3 text-center">
                        <div class="csslider infinity" id="slider1">
                            <input type="radio" name="slides" checked="checked" id="slides_1" />
                            <input type="radio" name="slides" id="slides_2" />
                            <input type="radio" name="slides" id="slides_3" />
                            <input type="radio" name="slides" id="slides_4" />
                            <input type="radio" name="slides" id="slides_5" />
                            <ul class="banner_slide_bg">
                            <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND cat_id = '$cat' ";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }
                   ?> 

                            
                            
                                <li>
                                    <img src="../back/images/<?php echo $image; ?>" alt="" class="img-fluid new_img1">
                                </li>
                                 <?php } }?>
                               
                            </ul>
                   
                            <div class="navigation">
                                <div>
                                    <label for="slides_1"></label>
                                    <label for="slides_2"></label>
                                    <label for="slides_3"></label>
                                    <label for="slides_4"></label>
                                    <label for="slides_5"></label>
                                </div>
                            </div>

                        </div>
                       
                    </div>
  </div>
            </div>
        </div>
                <?php } else {?>

              
                  
                       <div class="col-lg-6 img-banner-w3 text-center">
                        <div class="csslider infinity" id="slider1">
                            <input type="radio" name="slides" checked="checked" id="slides_1" />
                            <input type="radio" name="slides" id="slides_2" />
                            <input type="radio" name="slides" id="slides_3" />
                            <input type="radio" name="slides" id="slides_4" />
                            <input type="radio" name="slides" id="slides_5" />
                            <ul class="banner_slide_bg">
                            <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }
                   ?> 

                            
                            
                                <li>
                                    <img src="../back/images/<?php echo $image; ?>" alt="" class="img-fluid new_img1">
                                </li>
                                 <?php } }?>
                               
                            </ul>
                   
                            <div class="navigation">
                                <div>
                                    <label for="slides_1"></label>
                                    <label for="slides_2"></label>
                                    <label for="slides_3"></label>
                                    <label for="slides_4"></label>
                                    <label for="slides_5"></label>
                                </div>
                            </div>

                        </div>
                       
                    </div>

               

                </div>
            </div>
        </div>
                  <?php  }?>  
<div class="breadcrumb-w3ls py-1">
        <div class="container">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Home</li>
            </ol>
            <form action="" method="POST">
                    <div class="form-group">
                        <input type="text" class="form-control" size="50" placeholder="Search Product" name="Search" required="">
                        <button type="submit" name="submit-search" class="btn" style="background-color: var(--first-color);
    position: relative;
    left: 955px;
    top: -42px;padding: 10px; width: 100px;color: white;">Search</button>
                        
                    </div>
                </form>
        </div>
    </div>
    <br><br>

        <!------------------ DISCOUNT -------------------->
        <section class="discount section">
            <div class="discount-section">
                <div class="discount__container container grid">
                    <img src="assets/img/discount.png" alt="" class="discount_img">
                    <div class="discount-data">
                        <h2 class="discount_tittle">50% Discount<br>On New Products</h2>
                        <a href="#" class="button">Go to New</a>
                    </div>
                </div>
            </div>
            
        </section>


        <!------------------NEW ARRIVALS ---------------->
        <!-- this block is used to get data from the database using product and cat table if user click on category table then show all categoery respective to the category and also show product  -->
      
                <?php if (isset($cat)) { ?>
                      <section class="new section">
            <h2 class="section__title">New Arrivals</h2>
            <div class="new__container container">
                <div class="swiper new-swiper">
                <div class="swiper-wrapper">

                    <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND cat_id = '$cat' AND pro_feature = 'New'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    // fetch assoc function is  use to get data from the database and store into all variable
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }

                                        ?>

                        <!--New-content 1-->
                        <div class="new__content swiper-slide">
                            <div class="new__tag">New</div>
                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                            <h3 class="new__tittle"><?php echo $name ?></h3>
                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                            <div class="new_prices">
                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ',') ?></span>
                                        <!-- <span class="new_discount">$29.99</span> -->
                            </div>
                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                <i class="bx bx-cart-alt new_icon"></i>
                            </a>
                        </div>
                    <?php } }else{ echo "<h3><b>No Product Available.</b></h3>"; } ?>
                    </div>
                </div>
            </div>
            
        </section>
        <!-- close all category and product -->
        <!-- this fuctionalty is work for searching if user can search specific search about the product then user search the product -->
        <?php }else{ 
                    if (isset($_POST['submit-search'])) {
                        $search = $_POST['Search'];
                    
                    ?>
           <?php 
                        $select = "SELECT * FROM product WHERE name LIKE '%$search%' OR price LIKE '%$search%'  AND  role = 'Enable'";
                        $run    = $database->query($select);
                        $num    = $run->num_rows;
                        if ($num) {
                            while ($all = $run->fetch_assoc()) {

                                $p_id   = $all['id'];
                                $image  = $all['image'];
                                $name   = $all['name'];
                                $price  = $all['price'];
                                $cat_id = $all['cat_id'];

                                $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                $qry_run = $database->query($cat_qry);
                                $qry_num = $qry_run->num_rows; 
                                if($qry_num == 0){

                                    $cat_name = '-';

                                }else{

                                    $cat_row = $qry_run->fetch_assoc();
                                    $cat_name = $cat_row['name'];

                                }



                                ?>
            <div class="new__container container">
                <div class="swiper new-swiper">
                <div class="swiper-wrapper">
                    
                                 <div class="new__content swiper-slide">
                            <div class="new__tag">New</div>
                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                            <h3 class="new__tittle"><?php echo $name ?></h3>
                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                            <div class="new_prices">
                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ',') ?></span>
                                        <span class="new_discount">$40.99</span>
                            </div>
                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                <i class="bx bx-cart-alt new_icon"></i>
                            </a>
                        </div>
                        <?php } } ?>
                    </div>
                </div>
            </div>
          <!-- End Search  -->
        <?php } else{?>

                <section class="new section">
                    <h2 class="section__title">New Arrivals</h2>
                    <div class="new__container container">
                        <div class="swiper new-swiper">
                            <div class="swiper-wrapper">
                                <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND pro_feature = 'New'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }

                                        ?>
                                        <div class="new__content swiper-slide">
                                            <div class="new__tag">New</div>
                                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                                            <h3 class="new__tittle"><?php echo $name ?></h3>
                                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                                            <div class="new_prices">
                                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ',') ?></span>
                                                        <!-- <span class="new_discount">$49.99</span> -->
                                            </div>
                                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                                <i class="bx bx-cart-alt new_icon"></i>
                                            </a>
                                        </div>
                    <?php } }   ?>

                            </div>
                        </div>
                    </div>
                </section>    
                  <?php } }   ?>  
                  
        <!-- Old Arrivals -->
        <?php if (isset($cat)) { ?>
                      <section class="new section">
            <h2 class="section__title">Old Arrivals</h2>
            <div class="new__container container">
                <div class="swiper new-swiper">
                <div class="swiper-wrapper">
                    <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND cat_id = '$cat' AND pro_feature = 'Old'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }

                                        ?>

                        <!--New-content 1-->
                        <div class="new__content swiper-slide">
                            <div class="new__tag">Old</div>
                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                            <h3 class="new__tittle"><?php echo $name ?></h3>
                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                            <div class="new_prices">
                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ',') ?></span>
                                        <span class="new_discount">$49.99</span>
                            </div>
                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                <i class="bx bx-cart-alt new_icon"></i>
                            </a>
                        </div>
                    <?php } }else{ echo "<h3><b>No Product Available.</b></h3>"; } ?>
                    </div>
                </div>
            </div>
            
        </section>
        <?php }else{ 
                    if (isset($_POST['submit-search'])) {
                        $search = $_POST['Search'];
                    
                    ?>
           <?php 
                        $select = "SELECT * FROM product WHERE name LIKE '%$search%' OR price LIKE '%$search%'  AND  role = 'Enable'";
                        $run    = $database->query($select);
                        $num    = $run->num_rows;
                        if ($num) {
                            while ($all = $run->fetch_assoc()) {

                                $p_id   = $all['id'];
                                $image  = $all['image'];
                                $name   = $all['name'];
                                $price  = $all['price'];
                                $cat_id = $all['cat_id'];

                                $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                $qry_run = $database->query($cat_qry);
                                $qry_num = $qry_run->num_rows; 
                                if($qry_num == 0){

                                    $cat_name = '-';

                                }else{

                                    $cat_row = $qry_run->fetch_assoc();
                                    $cat_name = $cat_row['name'];

                                }



                                ?>
            <div class="new__container container">
                <div class="swiper new-swiper">
                <div class="swiper-wrapper">
                    
                                 <div class="new__content swiper-slide">
                            <div class="new__tag">Old</div>
                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                            <h3 class="new__tittle"><?php echo $name ?></h3>
                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                            <div class="new_prices">
                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ',') ?></span>
                                        <span class="new_discount">$49.99</span>
                            </div>
                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                <i class="bx bx-cart-alt new_icon"></i>
                            </a>
                        </div>
                        <?php } } ?>
                    </div>
                </div>
            </div>
          
        <?php } else{?>

                <section class="new section">
                    <h2 class="section__title">Old Arrivals</h2>
                    <div class="new__container container">
                        <div class="swiper new-swiper">
                            <div class="swiper-wrapper">
                                <?php 
                                $select = "SELECT * FROM product WHERE role = 'Enable' AND pro_feature = 'Old'";
                                $run    = $database->query($select);
                                $num    = $run->num_rows;
                                if ($num) {
                                    while ($all = $run->fetch_assoc()) {

                                        $p_id   = $all['id'];
                                        $image  = $all['image'];
                                        $name   = $all['name'];
                                        $price  = $all['price'];
                                        $cat_id = $all['cat_id'];


                                        $cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
                                        $qry_run = $database->query($cat_qry);
                                        $qry_num = $qry_run->num_rows; 
                                        if($qry_num == 0){

                                            $cat_name = '-';

                                        }else{

                                            $cat_row = $qry_run->fetch_assoc();
                                            $cat_name = $cat_row['name'];

                                        }

                                        ?>
                                        <div class="new__content swiper-slide">
                                            <div class="new__tag">Old</div>
                                            <img src="../back/images/<?php echo $image; ?>" alt="" class="new_img">
                                            <h3 class="new__tittle"><?php echo $name ?></h3>
                                            <span class="new__subtittle">Category | <a href="index.php?cat=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></span>
                                            <div class="new_prices">
                                                        <span class="new_price"><?php echo '$'.number_format($price, 0,'.', ','); ?></span>
                                                        <span class="new_discount">$49.99</span>
                                            </div>
                                            <a href="product_details.php?id=<?php echo $p_id; ?>" class="button new__button">
                                                <i class="bx bx-cart-alt new_icon"></i>
                                            </a>
                                        </div>
                    <?php } }   ?>

                            </div>
                        </div>
                    </div>
                </section>    
                  <?php } }   ?>  

        <!-- End Old Arrivals -->
        <!------------------ STEPS ------------------->
        
        <section class="steps section container">
         <div class="steps__bg">
             <h2 class="section__title">How to order products<br>from e-shopper</h2>
             <div class="steps_cointainer grid">
                <!-- STEPS CARD 1 !-->
                 <div class="steps__card">
                     <div class="steps_card-number">01</div>
                     <h3 class="steps__card-tittle">Choose Products</h3>
                     <p class="steps__card-description">
                         We have several varities products you can choose from.
                     </p>
                 </div>
                 <!-- STEPS CARD 2 !-->
                 <div class="steps__card">
                     <div class="steps_card-number">02</div>
                     <h3 class="steps__card-tittle">place an order</h3>
                     <p class="steps__card-description">
                         once your order is set, we move to the next step which is the shipping.
                     </p>
                 </div>
                 <!-- STEPS CARD 3 !-->
                 <div class="steps__card">
                     <div class="steps_card-number">03</div>
                     <h3 class="steps__card-tittle">Get order delivered</h3>
                     <p class="steps__card-description">
                         Our delivery process is easy you receive the order direct to your home.
                     </p>
                 </div>
             </div>
         </div>
        </section>


        <!----------------- NEWSLETTER -------------->
        <section class="newsletter section">
            <div class="newsletter_container container">
                <h2 class="section__title">Our newsletter</h2>
                <p class="newsletter_description">
                    Promotion new products and sales. Directly to your inbox
                </p>
                <form action="" class="newsletter_form">
                    <input type="text" placeholder="Enter your Email" class="newsletter_input">
                    <button class="button">Suscribe</button>
                </form>
            </div>
            
            
        </section>
    </main>

    <!-------------------- FOOTER ------------------>
             


    <!------------------ SCROLL UP ----------------->
    <a href="#" class="scrollup" id="scroll-up">
        <i class="bx bx-up-arrow-alt scrollup__icon"></i>
    </a>

    <!---------------- STYLE SWITCHER --------------->
      <div class="style__switcher">
          <div class="style__switcher-toogler s__icon">
              <i class="bx bxs-cog bx-spin"></i>
          </div>
          <h4>Theme Colors</h4>
          <div class="theme__colors js-theme-colors">
              <button type="button" data-js-theme-color="color-1" class="js-theme-color-item  theme__button color-1"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-2" class="js-theme-color-item theme__button color-2"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-3" class="js-theme-color-item theme__button color-3"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-4" class="js-theme-color-item theme__button color-4"><i class="bx bx-check"></i></button>
              <button type="button" data-js-theme-color="color-5" class="js-theme-color-item theme__button color-5"><i class="bx bx-check"></i></button>
          </div>
      </div>
    <!---------------- SWIPER JS -------------------->
    <script src="assets/js/swiper-bundle.min.js"></script>

    <!----------------- JS -------------------->
    <script src="assets/js/main.js"></script>
</body>
</html>