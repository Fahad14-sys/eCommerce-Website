<div id="wrapper">

<!----->
        <nav class="navbar-default navbar-static-top" role="navigation">
             <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <h1> <a class="navbar-brand" href="index.php">Admin</a></h1>         
               </div>
             <div class=" border-bottom">            
                <br>
                <center>
                Welcome To Admin Backend
                </center>
         
            <div class="clearfix" style="margin-left: 50%">
       
             </div>
             </div>

      
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                
                    <li>
                        <a href="index.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>


                    <li>
                        <a href="admin_mem.php" class=" hvr-bounce-to-right"><i class="fa fa-users nav_icon "></i><span class="nav-label">Manage Members</span> </a>
                    </li>


                    <li>
                        <a href="admin_cat.php" class=" hvr-bounce-to-right"><i class="fa fa-file nav_icon "></i><span class="nav-label">Manage Category</span> </a>
                    </li>


                    <li>
                        <a href="admin_pro.php" class=" hvr-bounce-to-right"><i class="fa fa-file nav_icon "></i><span class="nav-label">Manage Products</span> </a>
                    </li>


                    <li>
                        <a href="admin_order.php" class=" hvr-bounce-to-right"><i class="fa fa-file nav_icon "></i><span class="nav-label">Orders</span> </a>
                    </li>
                    <li>
                        <a href="fb.php" class=" hvr-bounce-to-right"><i class="fa fa-home nav_icon "></i><span class="nav-label">Feedback</span> </a>
                    </li>

                    <!-- <li>
                        <a href="report.php" class=" hvr-bounce-to-right"><i class="fa fa-file nav_icon "></i><span class="nav-label">Report</span> </a>
                    </li> -->

                    <li>
                        <a href="../front/index.php" class=" hvr-bounce-to-right"><i class="fa fa-home nav_icon "></i><span class="nav-label">Front</span> </a>
                    </li>



                    <li>
                        <a href="out.php" class=" hvr-bounce-to-right"><i class="fa fa-sign-out nav_icon "></i><span class="nav-label">Logout</span> </a>
                    </li>


                   


                </ul>
            </div>
            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
       