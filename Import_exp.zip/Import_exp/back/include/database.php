<?php 


ob_start();
session_start();

$database = new mysqli('localhost','root','','Import_exp');






?>