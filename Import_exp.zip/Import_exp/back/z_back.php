<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>


<?php 

$user_id = $_SESSION['id'];


?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Personal Information</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->













<br><br>
<?php include("include/footer.php"); ?>