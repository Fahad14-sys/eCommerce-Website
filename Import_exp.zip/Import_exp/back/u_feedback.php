<?php include("include/header.php"); ?>
<?php include("include/u_nav.php"); ?>


<?php 

$user_id = $_SESSION['id'];

?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="user.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Give FeedBacks</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->


<div class="profile">
<div class="container">




<div class="col-md-12">
	<div class="banner">
		<form method="POST" action="">
			<textarea name="fb" class="form-control" placeholder="Feedback.." required></textarea><br>
			<input type="submit" name="fb_btn" class="btn btn-danger">
		</form>
	</div>



<?php 




if (isset($_POST['fb_btn'])) {
	
	$fb = $_POST['fb'];
	$insert = "INSERT INTO fb(user_id, detail) VALUES('$user_id','$fb')";
	$run 	= $database->query($insert);
	if ($run) {
		echo "<br /><p class='alert alert-success'>Feedback Added</p>";
	}else{
		echo "<p class='alert alert-danger'>Adding Error</p>";
	}

}



?>







</div>
</div></div>
<br><br>
<?php include("include/footer.php"); ?>