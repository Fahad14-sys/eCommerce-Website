<?php include("include/header.php"); ?>
<?php include("include/u_nav.php"); ?>


<?php 

$user_id = $_SESSION['id'];

?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="user.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Orders</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->


<div class="profile">
<div class="container-fluid">




<div class="col-md-12">
	<div class="banner">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Name</th>
					<th>Image</th>
					<th>Qty</th>
					<th>Size</th>
					<th>Color</th>
					<th>Total Price</th>
					<th>Date</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php 

					$name = "SELECT * FROM my_order WHERE user_id = '$user_id'";

					$name_run = $database->query($name);

					$num = $name_run->num_rows;

					if ($num) {

						while ($all = $name_run->fetch_assoc()) {
							
							$id 		= $all['id'];
							$item_id 	= $all['item_id'];
							$user_id 	= $all['user_id'];
							$contact 	= $all['contact'];
							$address 	= $all['address'];
							$city 		= $all['city'];
							$province 	= $all['province'];
							$b_nam 		= $all['b_nam'];
							$b_account 	= $all['b_account'];
							$date 		= $all['date'];
							$role 		= $all['role'];
							$qty 		= $all['qty'];
							$size 		= $all['size'];
							$color 		= $all['color'];



							$cat_qry = "SELECT * FROM product WHERE id = '{$item_id}'";
							$qry_run = $database->query($cat_qry);
							$qry_num = $qry_run->num_rows; 
							if($qry_num == 0){

								$cat_name = '-';

							}else{

								$cat_row = $qry_run->fetch_assoc();
								$p_name = $cat_row['name'];
								$p_image = $cat_row['image'];
								$p_price = $cat_row['price'];
								$p_qty = $cat_row['qty'];

							}



					?>

					<td><?php echo $p_name; ?></td>
					<td><img src="images/<?php echo $p_image; ?>" width="50px" height="50px"></td>
					<td><?php echo $qty; ?></td>
					<td><?php echo $size; ?></td>
					<td><?php echo $color; ?></td>
					<td><?php echo $qty * $p_price; ?></td>
					<td><?php echo $date; ?></td>
					<td><?php echo $role; ?></td>
				</tr>
						<?php } }else{ echo "<td>No Record Found.</td>"; } ?>
			</tbody>
		</table>
	</div>



<?php 


if (isset($_GET['edit'])) {

$edit_id = $_GET['edit'];

$get = "SELECT * FROM my_order WHERE id = '$edit_id'";
$run = $database->query($get);
$fetch = $run->fetch_assoc();

$id 		= $fetch['id'];
$role 		= $fetch['role'];

?>

<br>
<div class="banner">

<form method="POST" action="admin_order.php">
	
	<select class="form-control" name="role">
		<option><?php echo $role; ?></option>
		<option value disabled selected>-- Choose Status --</option>
		<option>Recieved</option>
		<option>Pending</option>
	</select>
	<br>
	<input type="hidden" name="id" value="<?php echo $id ?>">
	<input type="submit" name="update" class="btn btn-danger" value="Update">
	<input type="submit" name="cancel" class="btn btn-primary" value="Cancel">

</form>
	
</div>


<?php } 


if (isset($_POST['update'])) {
		
	$u_id 		= $_POST['id'];
	$u_role 	= $_POST['role'];
	

	$update = "UPDATE my_order SET role = '$u_role' WHERE id = '$u_id'";
	$update_run = $database->query($update);
	
	if ($update_run) {
		
		echo "<br><p class='alert alert-success'>Members Updated</p>";
		header("refresh: 1");

	}
	else
	{

		echo "<p class='alert alert-success'>Updating Error</p>";

	}

}




?>







</div>
</div></div>
<br><br>
<?php include("include/footer.php"); ?>