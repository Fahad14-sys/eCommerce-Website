<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>



<?php 

$u_role 	 = $_SESSION['role'];

if (!isset($u_role) AND $u_role != 'admin') {
	
	header("Location: out.php");
}


$user_id = $_SESSION['id'];



?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Manage Category</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->


<div class="profile">




<?php 


if (isset($_POST['add'])) {
	
	$cat_name 	= $_POST['cat_name'];

	$check 	= "SELECT * FROM cat WHERE name = '{$cat_name}'";

	$check_run = $database->query($check);

	$new 	= $check_run->num_rows;

	if ($new == 0) {
		
	$add 	= "INSERT INTO cat(name) VALUES('{$cat_name}')";

	$add_run = $database->query($add);

	if ($add_run) {
		
		echo "<p class='alert alert-success'>Category Added</p>";

	}else{

		echo "<p class='alert alert-danger'>Category Adding Error</p>";
	}


	}else{

	echo "<p class='alert alert-danger'>Category Already Added</p>";	
	}

}



if (isset($_GET['del'])) {
	
	$del_id = $_GET['del'];

	$del = "DELETE FROM cat WHERE id = '$del_id'";

	$del_run = $database->query($del);

	if ($del_run) {
		
		header("Location: admin_cat.php");

	}else{

		echo "<p class='alert alert-danger'>Deleting Error</p>";		

	}

}


?>




<div class="col-md-4">
	<div class="banner">
		<form method="POST">
			<input type="text" name="cat_name" class="form-control" placeholder="Category Name"><br>
			<input type="submit" name="add" class="btn btn-primary" value="Add">
		</form>
	</div>
</div>





<div class="col-md-8">
	<div class="banner">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Name</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php 

					$name = "SELECT * FROM cat";

					$name_run = $database->query($name);

					$num = $name_run->num_rows;

					if ($num) {

						while ($all = $name_run->fetch_assoc()) {
							
							$id 	= $all['id'];
							$name 	= $all['name'];

					?>

					<td><?php echo $name; ?></td>
					<td>
						<a href="admin_cat.php?edit=<?php echo $id; ?>" class="btn btn-primary">Edit</a>
					</td>
					<td>
						<a href="admin_cat.php?del=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
					</td>
				</tr>
						<?php } }else{ echo "<td>No Record Found.</td>"; } ?>
			</tbody>
		</table>
	</div>



<?php 


if (isset($_GET['edit'])) {

$edit_id = $_GET['edit'];

$get = "SELECT * FROM cat WHERE id = '$edit_id'";
$run = $database->query($get);
$fetch = $run->fetch_assoc();

$id = $fetch['id'];
$name = $fetch['name'];

?>

<br>
<div class="banner">

<form method="POST" action="admin_cat.php">
	
	<input type="text" name="name" class="form-control" value="<?php echo $name; ?>"><br>
	<input type="hidden" name="id" value="<?php echo $id ?>">
	<input type="submit" name="update" class="btn btn-danger" value="Update">
	<input type="submit" name="cancel" class="btn btn-primary" value="Cancel">

</form>
	
</div>


<?php } 


if (isset($_POST['update'])) {
		
	$u_id 	= $_POST['id'];
	$name 	= $_POST['name'];

	$update = "UPDATE cat SET name = '{$name}' WHERE id = '$u_id'";
	$update_run = $database->query($update);
	
	if ($update_run) {
		
		echo "<p class='alert alert-success'>Category Updated</p>";

	}
	else
	{

		echo "<p class='alert alert-success'>Updating Error</p>";

	}

}




?>







</div>
</div>
<br><br>
<?php include("include/footer.php"); ?>