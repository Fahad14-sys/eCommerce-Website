<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>

<?php 


$user_id = $_SESSION['id'];


?>


<div class="container-fluid">



                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Manage Customer</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">Home</a></li>
                            <li class="breadcrumb-item active">Manage Customer</li>
                        </ol>
                    </div>
                </div>
    

                <div class="row">
                   
                    







                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-block">
                                <center> 
                                    
                                    Manage Customers

                                </center>
                            </div>
                        </div>
                    </div>





                    <?php 


                    if (isset($_GET['edit'])) {
                        
                        $get = $_GET['edit'];


                        $edit = "SELECT * FROM members WHERE id = '$get'";
                        $edit_run = $database->query($edit);
                        $fet    = $edit_run->fetch_assoc();

                        $name       = $fet['name'];
                        $email      = $fet['email'];
                        $password   = $fet['password'];
                        $cnic       = $fet['cnic'];
                        $number     = $fet['number'];
                        $address    = $fet['address'];


                        ?>


                        <div class="col-lg-12 col-xlg-12 col-md-12">
                            <a href="admin_mem.php" class="btn btn-danger pull-right">X</a><br><br>
                            <div class="card">
                                <div class="card-block">

                                    <form method="POST">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Name</th>
                                            <th><input type="text" name="name" class="form-control" value="<?php echo $name; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <th><input type="email" name="email" class="form-control" value="<?php echo $email; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Password</th>
                                            <th><input type="text" name="password" class="form-control" value="<?php echo $password; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Cnic</th>
                                            <th><input type="number" name="cnic" class="form-control" value="<?php echo $cnic; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Contact</th>
                                            <th><input type="number" name="number" class="form-control" value="<?php echo $number; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Address</th>
                                            <th><input type="text" name="address" class="form-control" value="<?php echo $address; ?>"></th>
                                        </tr>
                                        <tr>
                                            <th>Update</th>
                                            <th><input type="submit" name="update" class="btn btn-danger" value="<?php echo "Update"; ?>"></th>
                                        </tr>
                                    </table>
                                    </form>




                                    <?php 


                                    if (isset($_POST['update'])) {
                                        
                                        $name           = $_POST['name'];
                                        $email          = $_POST['email'];
                                        $password       = $_POST['password'];
                                        $cnic           = $_POST['cnic'];
                                        $number         = $_POST['number'];
                                        $address        = $_POST['address'];



                                        $update_sql     = "UPDATE members SET name = '$name', email =
                                         '$email', password = '$password', cnic = '$cnic'
                                         ,number = '$number' , address = '$address' WHERE id = '$get'";

                                        $update_run = $database->query($update_sql);

                                        if ($update_run) {
                                            
                                            echo '<p class="alert alert-success">Updated</p>';
                                            header("Refresh: 1");

                                        }else{

                                            echo '<p class="alert alert-danger">Updating Error</p>';

                                        }


                                    }



                                    ?>





                                </div>
                            </div>
                        </div>





                    <?php } ?>







                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        <div class="card">
                            <div class="card-block">


                                <?php 


                                if (isset($_GET['del'])) {
                                    
                                    $del_id = $_GET['del'];

                                    $delete = "DELETE FROM members WHERE id = '$del_id'";
                                    $delete_run = $database->query($delete);

                                    if ($delete_run) {
                                        echo "<p class='alert alert-success'>Deleted</p>";
                                        header("Location: admin_mem.php");
                                    }else{
                                        echo "<p class='alert alert-danger'>Deleting Error</p>";
                                    }

                                }


                                ?>


                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Password</th>
                                            <th>CNIC</th>
                                            <th>Contact</th>
                                            <th>Address</th>
                                            <!-- <th>Status</th>
                                            <th>OPT</th> -->
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php 

                                            $view = "SELECT * FROM  members WHERE role = 'user'";
                                            $res  = $database->query($view);
                                            if ($res->num_rows) {

                                            $count = 0;

                                            while ($row = $res->fetch_assoc()) {
                                            	
                                            $name       = $row['name'];
                                            $email      = $row['email'];
                                            $password   = $row['password'];
                                            $cnic       = $row['cnic'];
                                            $number     = $row['number'];
                                            $address    = $row['address'];
                                            $status     = $row['status'];
                                            $id         = $row['id'];

                                            $count++;

                                            ?>

                                        <td><?php echo $count ?></td>
                                        <td><?php echo $name ?></td>
                                        <td><?php echo $email ?></td>
                                        <td><?php echo $password ?></td>
                                        <td><?php echo $cnic ?></td>
                                        <td><?php echo $number ?></td>
                                        <td><?php echo $address ?></td>
                                        
                                        

                                        

                                        <td><a href="admin_mem.php?edit=<?php echo $id ?>" class="btn btn-primary">Edit</a></td>
                                        <td><a href="admin_mem.php?del=<?php echo $id ?>" class="btn btn-danger">Delete</a></td>

                                        </tr>
                                            <?php } } ?>
                                    </tbody>
                                </table>
                                

                                <?php 


                                if (isset($_GET['confirm'])) {
                                    
                                    $get_id = $_GET['confirm'];

                                    $conf   = "UPDATE members SET status = 'Confirm' WHERE id = '$get_id'";
                                    $res_conf = $database->query($conf);

                                    if ($res_conf) {
                                        header("Location: admin_mem.php");
                                    }else{
                                        echo "Confirm Not Don";
                                    }

                                }


                                if (isset($_GET['reject'])) {
                                    
                                    $get_id = $_GET['reject'];

                                    $conf   = "UPDATE members SET status = 'Pending' WHERE id = '$get_id'";
                                    $res_conf = $database->query($conf);

                                    if ($res_conf) {
                                        header("Location: admin_mem.php");
                                    }else{
                                        echo "Confirm Not Don";
                                    }

                                }




                                ?>





                            </div>

                        </div>

                    </div>

                    
                
            </div>


            </div>




<?php include("include/footer.php"); ?>