<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>


<?php 

$u_role 	 = $_SESSION['role'];

if (!isset($u_role) AND $u_role != 'admin') {
	
	header("Location: out.php");
}


$user_id = $_SESSION['id'];



?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>View FeedBacks</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->


<div class="profile">
<div class="container">



<?php 





if (isset($_GET['del'])) {
	
	$del_id = $_GET['del'];

	$del = "DELETE FROM fb WHERE id = '$del_id'";

	$del_run = $database->query($del);

	if ($del_run) {
		
		header("Location: fb.php");

	}else{

		echo "<p class='alert alert-danger'>Deleting Error</p>";		

	}

}


?>





<div class="col-md-12">
	<div class="banner">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th>User</th>
					<th>Details</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php 

					$name = "SELECT * FROM fb";

					$name_run = $database->query($name);

					$num = $name_run->num_rows;

					if ($num) {

						$count = 0;
						while ($all = $name_run->fetch_assoc()) {
							
							$id 			= $all['id'];
							$user_id 		= $all['user_id'];
							$detail 		= $all['detail'];

							$count++;

							$cat_qry = "SELECT * FROM members WHERE id = '{$user_id}'";
							$qry_run = $database->query($cat_qry);
							$qry_num = $qry_run->num_rows; 
							if($qry_num == 0){

								$cat_name = '-';

							}else{

								$cat_row = $qry_run->fetch_assoc();
								$p_name = $cat_row['name'];
								

							}



					?>

					<td><?php echo $count; ?></td>
					<td><?php echo $p_name; ?></td>
					<td><?php echo $detail; ?></td>
					<td>
						<a href="fb.php?del=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
					</td>
				</tr>
						<?php } }else{ echo "<td>No Record Found.</td>"; } ?>
			</tbody>
		</table>
	</div>









</div>
</div></div>
<br><br>
<?php include("include/footer.php"); ?>