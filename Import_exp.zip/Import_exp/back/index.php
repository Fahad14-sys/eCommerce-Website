<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>
<style>
	.bckimg{
		
	}
</style>
<div class="bckimg"></div>

<?php 

$u_role 	 = $_SESSION['role'];

if (!isset($u_role) AND $u_role != 'admin') {
	
	header("Location: out.php");
}


$user_id = $_SESSION['id'];



$select = "SELECT * FROM members WHERE id = '$user_id'";
$select_run = $database->query($select);
$all 	= $select_run->fetch_assoc();

$name 		= $all['name'];
$email 		= $all['email'];
$password 	= $all['password'];
$cnic 		= $all['cnic'];
$number 	= $all['number'];
$address 	= $all['address'];


?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Personal Information</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->

<div class="profile">



<?php 




if (isset($_POST['update'])) {
	
	$name 		= $_POST['name'];
	$email 		= $_POST['email'];
	$password 	= $_POST['password'];
	$cnic 		= $_POST['cnic'];
	$number 	= $_POST['number'];
	$address 	= $_POST['address'];


	$update 	= "UPDATE members SET name = '$name', email = '$email', password = '$password', cnic = '$cnic', number = '$number', address = '$address' WHERE id = '$user_id'";

	$update_run = $database->query($update);
	
	if ($update_run) {
		
		echo "<p class='alert alert-success'>Profile Updated</p>";

	}else{

		echo "<p class='alert alert-danger'>Profile Updating ERROR</p>";

	}

}





?>








<div class="banner">

<table class="table">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Password</th>
			<th>View</th>
			<th>Edit</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><?php echo $name; ?></td>
			<td><?php echo $email ?></td>
			<td><?php echo $password ?></td>
			<td>
				<a href="index.php?view" class="btn btn-primary">View</a>
			</td>
			<td>
				<a href="index.php?edit" class="btn btn-warning">Edit</a>
			</td>
		</tr>
	</tbody>
</table>

</div>




<?php 

if (isset($_GET['view'])) { ?>

<br>

<div class="banner">

<table class="table table-bordered table-hover">
	<tr>
		<th>Cnic</th>
		<td><?php echo $cnic ?></td>
	</tr>
	<tr>
		<th>Number</th>
		<td><?php echo $number ?></td>
	</tr>
	<tr>
		<th>Address</th>
		<td><?php echo $address ?></td>
	</tr>
	<tr>
		<th>Cancel</th>
		<form action="index.php" method="POST">
		<td><button type="submit" class="btn btn-danger">x</button></td>
		</form>
	</tr>
</table>

</div>


<?php } ?>








<?php 

if (isset($_GET['edit'])) { ?>

<br>

<div class="banner">

<table class="table table-bordered table-hover">
	<form action="" method="POST">
	<tr>
		<th>Name</th>
		<td><input type="text" name="name" class="form-control" value="<?php echo $name; ?>"></td>
	</tr>
	<tr>
		<th>Email</th>
		<td><input type="text" name="email" class="form-control" value="<?php echo $email; ?>"></td>
	</tr>
	<tr>
		<th>Password</th>
		<td><input type="text" name="password" class="form-control" value="<?php echo $password; ?>"></td>
	</tr>
	<tr>
		<th>Cnic</th>
		<td><input type="text" name="cnic" class="form-control" value="<?php echo $cnic; ?>"></td>
	</tr>
	<tr>
		<th>Number</th>
		<td><input type="text" name="number" class="form-control" value="<?php echo $number; ?>"></td>
	</tr>
	<tr>
		<th>Address</th>
		<td>
			<input type="text" name="address" class="form-control" value="<?php echo $address; ?>">
		</td>
	</tr>
	<tr>
		<th>Update</th>
		<td><button type="submit" name="update" class="btn btn-info">Update</button></td>
	</form>
	</tr>
	<tr>
		<th>Cancel</th>
		<form action="index.php" method="POST">
		<td><button type="submit" class="btn btn-danger">Cancel</button></td>
		</form>
	</tr>
</table>

</div>


<?php } ?>









</div>


<br><br>
<?php include("include/footer.php"); ?>