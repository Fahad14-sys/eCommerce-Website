<?php include("include/header.php"); ?>
<?php include("include/u_nav.php"); ?>

<?php
$user_id = $_SESSION['id'];

?>

<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>UserFeedback</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->



<div class="banner">

<table class="table table-bordered table-hover">
	<form action="" method="POST">
	<tr>
		<th>Enter Feedback</th>
		<td><input type="text" name="name" class="form-control"></td>
	</tr>
	
	<tr>
		<th>Button</th>
        <input type="hidden" name="u_id" value = <?php echo $user_id ?>>
		<td><button type="submit" name="add" class="btn btn-info">Submit</button></td>
	</form>
	</tr>
	
</table>

</div>

<?php
	if (isset($_POST['add'])) {
							
        $name 	= $_POST['name'];
        $u_id = $_POST['u_id'];
        $reg 	= "INSERT INTO fb(user_id, detail) VALUES('{$u_id}', '{$name}' )";
        $reg_run = $database->query($reg);

        if ($reg_run) {
									
            echo "<p class='alert alert-info'>Feedback Has Been Successfully Added</p>";

        }
        else{

            echo "<p class='alert alert-danger'>Feedback Has Not Been Successfully Added</p>";

        }



    }

?>













<br><br>
<?php include("include/footer.php"); ?>