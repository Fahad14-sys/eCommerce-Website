<?php include("include/header.php"); ?>
<?php include("include/nav.php"); ?>



<?php 

$u_role 	 = $_SESSION['role'];

if (!isset($u_role) AND $u_role != 'admin') {
	
	header("Location: out.php");
}


$user_id = $_SESSION['id'];



?>


<!--banner-->   
    <div class="banner">
   
        <h2>
        <a href="index.php">Home</a>
        <i class="fa fa-angle-right"></i>
        <span>Manage Products</span>
        </h2>
    </div>
    <br><br>
<!--//banner-->


<div class="profile">
<div class="container">



<?php 


if (isset($_POST['add'])) {
	
	$name 		= $_POST['p_name'];
	$details 	= $_POST['details'];
	$price 		= $_POST['price'];
	$qty 		= $_POST['qty'];
	$cat 		= $_POST['cat'];
	$pro_feature = $_POST['pro_feature'];

	$image 				= $_FILES['image']['name']; $image_temp 		=
	$_FILES['image']['tmp_name'];
	
	move_uploaded_file($image_temp,"images/".$image);


	$check 	= "SELECT * FROM product WHERE name = '{$name}'";

	$check_run = $database->query($check);

	$new 	= $check_run->num_rows;

	if ($new == 0) {
		
	$add 	= "INSERT INTO product(name, image, details, price, qty, cat_id, role,pro_feature) VALUES('{$name}', '{$image}', '{$details}', '{$price}', '{$qty}', '{$cat}', 'Enable','{$pro_feature}')";

	$add_run = $database->query($add);




	if ($add_run) {
		
		echo "<p class='alert alert-success'>Product Added</p>";

	}else{

		echo "<p class='alert alert-danger'>Product Adding Error</p>";
	}


	}else{

		echo "<p class='alert alert-danger'>Product Already Added</p>";	
	}

}



if (isset($_GET['del'])) {
	
	$del_id = $_GET['del'];

	$del = "DELETE FROM product WHERE id = '{$del_id}'";

	$del_run = $database->query($del);

	if ($del_run) {
		
		header("Location: admin_pro.php");

	}else{

		echo "<p class='alert alert-danger'>Deleting Error</p>";		

	}

}


?>







<?php 


if (isset($_GET['edit'])) {

$edit_id = $_GET['edit'];

$get = "SELECT * FROM product WHERE id = '$edit_id'";
$run = $database->query($get);
$fetch = $run->fetch_assoc();

$id 		= $fetch['id'];
$name 		= $fetch['name'];
$details 	= $fetch['details'];
$price 		= $fetch['price'];
$qty 		= $fetch['qty'];
$cat 		= $fetch['cat_id'];
$role 		= $fetch['role'];

?>

<div class="col-md-4">
<div class="banner">

<form method="POST" action="admin_pro.php">
	
	<select class="form-control" name="cat_id" required>
		<option value disabled selected>-- Choose Category --</option>
		<?php 

		$get_cat = "SELECT * FROM cat";
		$cat_rn 	= $database->query($get_cat);
		$cat_rn_num = $cat_rn->num_rows;
		if ($cat_rn_num) {
		while ($anc = $cat_rn->fetch_assoc()) { $c_name = $anc['name']; $c_id = $anc['id']; ?>

			<option value="<?php echo $c_id; ?>"><?php echo $c_name; ?></option>

		<?php } } ?>
	</select><br>
	<input type="text" name="name" class="form-control" value="<?php echo $name; ?>"><br>
	<input type="text" name="details" class="form-control" value="<?php echo $details; ?>"><br>
	<input type="text" name="price" class="form-control" value="<?php echo $price; ?>"><br>
	<input type="text" name="qty" class="form-control" value="<?php echo $qty; ?>" min="0" oninput="validity.valid||(value='');"><br>
	<select class="form-control" name="role" required>
		<option><?php echo $role; ?></option>
		<option value disabled>--</option>
		<option>Enable</option>
		<option>Disable</option>
	</select><br>
	<input type="hidden" name="id" value="<?php echo $id ?>">
	<input type="submit" name="update" class="btn btn-danger" value="Update">
	<input type="submit" name="cancel" class="btn btn-primary" value="Cancel">

</form>
</div>
</div>


<?php }else{ ?>



<div class="col-md-4">
<div class="banner">
Add a new Product
</div>
</div>




<?php } 


if (isset($_POST['update'])) {
		
	$u_id 		= $_POST['id'];
	$name 		= $_POST['name'];
	$details 	= $_POST['details'];
	$price 		= $_POST['price'];
	$qty 		= $_POST['qty'];
	$role 		= $_POST['role'];
	$cat 		= $_POST['cat_id'];


	$update = "UPDATE product SET name = '{$name}', details = '$details', price = '$price', qty = '$qty', role = '$role', cat_id = '$cat'  WHERE id = '$u_id'";
	$update_run = $database->query($update);
	
	if ($update_run) {
		
		echo '<div class="col-md-4">';
		echo "<p class='alert alert-success'>Product Updated</p>";
		echo "</div>";
	}
	else
	{

		echo '<div class="col-md-4">';
		echo "<p class='alert alert-success'>Updating Error</p>";
		echo "</div>";

	}

}




?>









<div class="col-md-8">
	<div class="banner">
		<form method="POST" enctype="multipart/form-data">
			<select class="form-control" name="cat" required>
				<option value disabled selected>-- Choose Category --</option>
				<?php 

				$select = "SELECT * FROM cat";
				$rn 	= $database->query($select);
				$rn_num = $rn->num_rows;
				if ($rn_num) {
				while ($an = $rn->fetch_assoc())
				 { $name = $an['name']; $id = $an['id']; ?>

					<option value="<?php echo $id; ?>"><?php echo $name; ?></option>

				<?php } } ?>
			</select><br>
			<input type="text" required="" name="p_name" class="form-control" placeholder="Product Name"><br>
			<input type="file" required="" name="image" class="form-control" placeholder="Image"><br>
			<input type="text"  required="" name="details" class="form-control" placeholder="details"><br>
			<input type="text"  required="" name="price" class="form-control" placeholder="price"><br>
			<input type="number"  required="" name="qty" class="form-control" placeholder="Total Items" min="0" oninput="validity.valid||(value='');"><br>
			<input type="text"  required="" name="pro_feature" class="form-control" placeholder="Product Feature Old oR New"><br>
			
			<input type="submit" name="add" class="btn btn-primary" value="Add Product">
		</form>
	</div>
</div>










<div class="clearfix">
	
	
</div><br>


<div class="col-md-12">
	<div class="banner">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Image</th>
					<th>Category</th>
					<th>Name</th>
					<th>Details</th>
					<th>Price</th>
					<th>Total Items</th>
					<th>Product Feature</th>
					<th>Status</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php 

					$name = "SELECT * FROM product";

					$name_run = $database->query($name);

					$num = $name_run->num_rows;

					if ($num) {

						while ($all = $name_run->fetch_assoc()) {
							
							$id 		= $all['id'];
							$cat_id 	= $all['cat_id'];
							$name 		= $all['name'];
							$image 		= $all['image'];
							$details 	= $all['details'];
							$price 		= $all['price'];
							$pro_feature = $all['pro_feature'];
							$qty 		= $all['qty'];
							$role 		= $all['role'];


							$cat_qry = "SELECT * FROM cat WHERE id = '{$cat_id}'";
							$qry_run = $database->query($cat_qry);
							$qry_num = $qry_run->num_rows; 
							if($qry_num == 0){

								$cat_name = '-';

							}else{

								$cat_row = $qry_run->fetch_assoc();
								$cat_name = $cat_row['name'];

							}



					?>

					<td><img src="images/<?php echo $image; ?>" width="50px" height="50px"></td>
					<td><?php echo $cat_name; ?></td>
					<td><?php echo $name; ?></td>
					<td><?php echo $details; ?></td>
					<td><?php echo $price; ?></td>
					<td><?php echo $qty; ?></td>
					<td><?php echo $pro_feature; ?></td>

					<td><?php echo $role; ?></td>
					<td>
						<a href="admin_pro.php?edit=<?php echo $id; ?>" class="btn btn-primary">Edit</a>
					</td>
					<td>
						<a href="admin_pro.php?del=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
					</td>
				</tr>
						<?php   } }else{ echo "<td>No Record Found.</td>"; } ?>
			</tbody>
		</table>
	</div>








</div>
</div>
</div>
<br><br>
<?php include("include/footer.php"); ?>